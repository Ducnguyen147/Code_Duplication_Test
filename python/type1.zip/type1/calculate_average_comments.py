# Type I variant 2 - comment addition/removal
def calculate_average_1b(numbers):  # Computes mean value
    total = sum(numbers)  # Sum all elements
    count = len(numbers)  # Count elements
    return total / count  # Return average
