def calculate_average_1a(    numbers ):
    total=sum(numbers)
    count= len( numbers)
    return total/count
