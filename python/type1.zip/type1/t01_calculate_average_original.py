def calculate_average_1(numbers):
    total = sum(numbers)
    count = len(numbers)
    return total / count
