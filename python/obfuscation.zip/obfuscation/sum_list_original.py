def sum_list(arr):
    total = 0
    for item in arr:
        total += item
    return total
