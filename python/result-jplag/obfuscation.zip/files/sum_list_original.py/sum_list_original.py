# Original implementation: Calculate the sum of all elements in a list.
def sum_list(arr):
    total = 0
    for item in arr:
        total += item
    return total
