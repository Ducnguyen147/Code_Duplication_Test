# file: is_prime_adv.py

import math
from functools import lru_cache
import logging
from typing import Dict

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@lru_cache(maxsize=None)
def is_prime(n: int) -> bool:
    """
    Return True if n is prime, False otherwise.
    Uses a few optimizations: 
      - trivial cases,
      - check divisibility by 2 and 3,
      - then test 6k ± 1 up to sqrt(n)
    Caches results for reuse.
    """
    logger.debug(f"Checking primality for n = {n}")
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        logger.debug(f"{n} divisible by 2")
        return False
    if n % 3 == 0:
        logger.debug(f"{n} divisible by 3")
        return False
    # Use 6k ± 1 rule
    limit = int(math.isqrt(n))
    i = 5
    step = 2
    while i <= limit:
        if n % i == 0:
            logger.debug(f"{n} divisible by {i}")
            return False
        logger.debug(f"{n} not divisible by {i}, next check i += {step}")
        i += step
        # alternate steps: 2, 4, 2, 4, ...
        step = 6 - step
    return True


if __name__ == "__main__":
    for num in [1,2,3,4,16,17,18,19,23,25,29]:
        print(f"is_prime({num}) = {is_prime(num)}")
