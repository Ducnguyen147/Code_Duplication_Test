# file: reverse_string_full.py

from typing import Union

def reverse_string(s: Union[str, list], method: str = "loop") -> Union[str, list]:
    """
    Reverse a string (or list) via different methods.

    method:
      - "loop": explicit loop, building result
      - "recursion": recursion (for smaller inputs)
      - "slice": Python slicing
    Raises ValueError for unsupported method.
    """
    if not isinstance(s, (str, list)):
        raise TypeError("reverse_string only supports str or list")
    if method == "slice":
        # slicing works similarly on str and list
        return s[::-1]
    elif method == "loop":
        res = []
        # if it's string, build list then join
        for x in s:
            res.insert(0, x)
        return "".join(res) if isinstance(s, str) else res
    elif method == "recursion":
        # base
        if len(s) <= 1:
            return s
        # recursion
        head = s[0]
        tail = s[1:]
        rev_tail = reverse_string(tail, method="recursion")
        if isinstance(s, str):
            return rev_tail + head
        else:
            return rev_tail + [head]
    else:
        raise ValueError(f"Unknown method '{method}'")


if __name__ == "__main__":
    s = "hello world"
    print(reverse_string(s, method="slice"))
    print(reverse_string(s, method="loop"))
    print(reverse_string(s, method="recursion"))
    # For list:
    L = [1,2,3,4,5]
    print(reverse_string(L, method="loop"))
    print(reverse_string(L, method="slice"))
    print(reverse_string(L, method="recursion"))
