# file: factorial_enhanced.py

import logging
from typing import Optional, Union

logger = logging.getLogger(__name__)
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.DEBUG)

def factorial(n: int, allow_neg: bool = False) -> Union[int, None]:
    """
    Compute the factorial n! iteratively, with optional handling of negative n.

    If n < 0 and allow_neg is False, raises ValueError.
    If n = 0, returns 1.
    Otherwise returns 1 * 2 * ... * n.

    Also logs intermediate steps when n is small (for debugging).
    """
    if not isinstance(n, int):
        raise TypeError(f"n must be int, got {type(n).__name__}")
    if n < 0:
        if allow_neg:
            logger.debug("Received negative n, allow_neg=True; returning None")
            return None
        else:
            raise ValueError("n must be non-negative")
    result = 1
    # For small n, log each multiplication
    for i in range(2, n + 1):
        prev = result
        result *= i
        if n <= 10:
            logger.debug(f"factorial: at i={i}, {prev} * {i} = {result}")
    return result


if __name__ == "__main__":
    for test in [0, 1, 5, 10]:
        print(f"factorial({test}) = {factorial(test)}")
    # Test negative with flag
    print("factorial(-3, allow_neg=True) →", factorial(-3, allow_neg=True))
