# file: gcd_verbose.py

from typing import Tuple

def gcd(a: int, b: int, trace: bool = False) -> int:
    """
    Compute the greatest common divisor (GCD) of integers a and b using Euclid's algorithm.

    If trace=True, prints intermediate (a, b) pairs at each iteration.
    Supports negative inputs by using absolute values.
    """
    if not (isinstance(a, int) and isinstance(b, int)):
        raise TypeError("Arguments must be integers")
    a, b = abs(a), abs(b)
    if trace:
        print(f"Starting gcd: a = {a}, b = {b}")
    while b != 0:
        q, r = divmod(a, b)
        if trace:
            print(f"gcd step: a = {a}, b = {b}, q = {q}, r = {r}")
        a, b = b, r
    if trace:
        print(f"Finished gcd: result = {a}")
    return a


if __name__ == "__main__":
    pairs = [(48, 18), (0, 5), (7, 13), (-12, 20)]
    for (x, y) in pairs:
        print(f"gcd({x}, {y}) = {gcd(x, y, trace=True)}")
