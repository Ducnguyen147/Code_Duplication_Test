# file: median_extended.py

from typing import List, Optional, Union

def median(xs: List[Union[int, float]], weights: Optional[List[float]] = None) -> float:
    """
    Return the median of list xs.

    If weights is provided (same length as xs), compute weighted median.
    If xs is empty, raises ValueError.

    Unweighted median logic:
      - Sort xs
      - If odd-length, return middle item
      - If even-length, return average of two middle items

    Weighted median logic:
      - Sort pairs by xs values, accumulate weights, find the point
        where cumulative weight passes half of total weight.
    """
    if not xs:
        raise ValueError("median of empty list is undefined")
    n = len(xs)
    if weights is not None:
        if len(weights) != n:
            raise ValueError("weights must match xs length")
        # Pair and sort
        pairs = sorted(zip(xs, weights), key=lambda p: p[0])
        total_w = sum(weights)
        cum = 0.0
        for (value, w) in pairs:
            cum += w
            if cum >= total_w / 2.0:
                return float(value)
        # fallback
        return float(pairs[-1][0])
    else:
        sorted_xs = sorted(xs)
        mid = n // 2
        if n % 2 == 1:
            return float(sorted_xs[mid])
        else:
            return (sorted_xs[mid - 1] + sorted_xs[mid]) / 2.0


if __name__ == "__main__":
    print(median([3, 1, 4, 2]))        # = (2 + 3) / 2 = 2.5
    print(median([3, 1, 4]))           # = 3
    print(median([1, 2, 3, 4, 5]))     # = 3
    print(median([1, 2, 3, 4], [1, 1, 1, 1]))  # unweighted path
    print(median([10, 20, 30, 40], [1, 3, 1, 1]))  # weighted example
