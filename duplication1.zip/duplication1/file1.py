def add_numbers_folder1(a, b):
    return a + b

def multiply_numbers_folder1(a, b):
    return a * b
