def add_values_folder1(a, b):
    return a + b

def multiply_values_folder1(a, b):
    return a * b
