function isPrime(n) {
    if (n < 2) {
        return false;
    }
    if (n % 2 === 0) {
        return n === 2;
    }
    let i = 3;
    while (i * i <= n) {
        if (n % i === 0) {
            return false;
        }
        i += 2;
    }
    return true;
}

module.exports = { isPrime };
