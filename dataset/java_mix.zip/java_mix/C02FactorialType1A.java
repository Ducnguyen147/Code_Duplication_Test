public class C02FactorialType1A {
    public static int fact(int n) {
        int r = 1;
        for (int i = 2; i <= n; i++) r *= i;
        return r;
    }
}
